from django.http import HttpResponse, HttpResponseRedirect
from .models import User
from django.contrib.auth import authenticate, login
from django.shortcuts import redirect, render
import logging
from django.contrib.auth.hashers import make_password, check_password




# Create your views here.
def home(request):    #request is the instance of HttpRequest class
    return HttpResponse("<h1> welcome! Friends </h1>")
def register(request):
    if request.method=='GET':
        return render(request, 'register.html')
    if request.method=='POST':
        username=request.POST['usern']
        password=request.POST['password']
        if User.objects.filter(username=username).exists():
            return render(request, 'register.html',{'error':'username already exists'})
        new_user=User(username=username, password=password)
        new_user.password=make_password(new_user.password)
        new_user.save()
        return redirect('/user_login')

def all_users(request):
    users=User.objects.all()
    return render(request,'all_users.html',{'users':users})

def login_page(req):
    return render(req,'login.html')

def user_dashboard(req):
    return render(req,'dashboard.html')

logger = logging.getLogger('my_error_django')
def login_view(request):
        if request.method == 'POST':
            usr = request.POST.get('usern')
            passw = request.POST.get('password')
            user=User.customer_id(usr)
            if user:
                match_passw=check_password(passw, user.password)
                if match_passw:
                    return HttpResponseRedirect('dashboard')  # Redirect to dashboard page
            else:
            # Capture audit trail for login failure
            # Your audit trail logic here
                return render(request, 'login.html', {'error': 'Invalid credentials or inactive user'})
        return render(request, 'login.html')


